<?php

namespace Tachyon\Actions;

use Tachyon\Enumerations\Capa;
use Tachyon\Exceptions\ClientException;
use Tachyon\Notifications;
use Tachyon\Providers\Suggestions;
use Tachyon\Utils;

trait User
{
	use Accounts;
	use Calendar;
	use Contacts;
	use Filters;
	use Folders;
	use Messages;
	use Attachments;
	use Pgp;
	use SMime;

	private ?Suggestions $oSuggestionsProvider = null;

	public function SuggestionsProvider(): Suggestions
	{
		if (null === $this->oSuggestionsProvider) {
			$this->oSuggestionsProvider = new Suggestions($this->fabrica('suggestions'));
		}

		return $this->oSuggestionsProvider;
	}

	/**
	 * @throws \MailSo\RuntimeException
	 */
	public function DoLogin() : array
	{
		try {
			$oAccount = $this->LoginProcess(
				\MailSo\Base\Utils::Trim($this->GetActionParam('Email', '')),
				new \Tachyon\Util\SensitiveString($this->GetActionParam('Password', ''))
			);
		} catch (\Throwable $oException) {
			$this->loginErrorDelay();
			throw $oException;
		}

		empty($this->GetActionParam('signMe', 0)) || $this->SetSignMeToken($oAccount);

		$sLanguage = $this->GetActionParam('language', '');
		if ($oAccount && $sLanguage) {
			$oSettings = $this->SettingsProvider()->Load($oAccount);
			if ($oSettings) {
				$sLanguage = $this->ValidateLanguage($sLanguage);
				$sCurrentLanguage = $oSettings->GetConf('language', '');

				if ($sCurrentLanguage !== $sLanguage) {
					$oSettings->SetConf('language', $sLanguage);
					$oSettings->save();
				}
			}
		}

		return $this->DefaultResponse($this->AppData(false));
	}

	public function DoLogout() : array
	{
		$bMain = true; // empty($_COOKIE[self::AUTH_ADDITIONAL_TOKEN_KEY]);
		$this->Logout($bMain);
		$bMain && $this->ClearSignMeData();
		return $this->TrueResponse();
	}

	public function DoAppDelayStart() : array
	{
		Utils::UpdateConnectionToken();

		$bMainCache = false;
		$bFilesCache = false;

		$iOneDay1 = 3600 * 23;
		$iOneDay2 = 3600 * 25;

		$sTimers = $this->StorageProvider()->Get(null,
			\Tachyon\Providers\Storage\Enumerations\StorageType::NOBODY, 'Cache/Timers', '');

		$aTimers = \explode(',', $sTimers);

		$iMainCacheTime = !empty($aTimers[0]) && \is_numeric($aTimers[0]) ? (int) $aTimers[0] : 0;
		$iFilesCacheTime = !empty($aTimers[1]) && \is_numeric($aTimers[1]) ? (int) $aTimers[1] : 0;

		if (0 === $iMainCacheTime || $iMainCacheTime + $iOneDay1 < \time()) {
			$bMainCache = true;
			$iMainCacheTime = \time();
		}

		if (0 === $iFilesCacheTime || $iFilesCacheTime + $iOneDay2 < \time()) {
			$bFilesCache = true;
			$iFilesCacheTime = \time();
		}

		if ($bMainCache || $bFilesCache) {
			if (!$this->StorageProvider()->Put(null,
				\Tachyon\Providers\Storage\Enumerations\StorageType::NOBODY, 'Cache/Timers',
				\implode(',', array($iMainCacheTime, $iFilesCacheTime))))
			{
				$bMainCache = $bFilesCache = false;
			}
		}

		if ($bMainCache) {
			$this->logWrite('Cacher GC: Begin');
			$this->Cacher()->GC(48);
			$this->logWrite('Cacher GC: End');

			$this->logWrite('Storage GC: Begin');
			$this->StorageProvider()->GC();
			$this->logWrite('Storage GC: End');
		} else if ($bFilesCache) {
			$this->logWrite('Files GC: Begin');
			$this->FilesProvider()->GC(48);
			$this->logWrite('Files GC: End');
		}

		return $this->TrueResponse();
	}

	public function DoSettingsUpdate() : array
	{
		$oAccount = $this->getAccountFromToken();

		$self = $this;
		$oConfig = $this->Config();

		$oSettings = $this->SettingsProvider()->Load($oAccount);
		$oSettingsLocal = $this->SettingsProvider(true)->Load($oAccount);

		if ($oConfig->Get('webmail', 'allow_languages_on_settings', true)) {
			$this->setSettingsFromParams($oSettings, 'language', 'string', function ($sLanguage) use ($self) {
				return $self->ValidateLanguage($sLanguage);
			});
		} else {
//			$oSettings->SetConf('language', $this->ValidateLanguage($oConfig->Get('webmail', 'language', 'en')));
		}
		$this->setSettingsFromParams($oSettings, 'hourCycle', 'string');

		if ($this->GetCapa(Capa::THEMES)) {
			$this->setSettingsFromParams($oSettingsLocal, 'Theme', 'string', function ($sTheme) use ($self) {
				return $self->ValidateTheme($sTheme);
			});
			$this->setSettingsFromParams($oSettings, 'fontSansSerif', 'string');
			$this->setSettingsFromParams($oSettings, 'fontSerif', 'string');
			$this->setSettingsFromParams($oSettings, 'fontMono', 'string');
		} else {
//			$oSettingsLocal->SetConf('Theme', $this->ValidateTheme($oConfig->Get('webmail', 'theme', 'Default')));
		}

		// Same ceiling the client is given, so a value the settings screen offers
		// is never silently reduced on the way in
		$iPerPageMax = static::messagesPerPageMax($this->Config());
		$this->setSettingsFromParams($oSettings, 'MessagesPerPage', 'int', function ($iValue) use ($iPerPageMax) {
			return \min($iPerPageMax, \max(10, $iValue));
		});

		$this->setSettingsFromParams($oSettings, 'Layout', 'int', function ($iValue) {
			return (
				\Tachyon\Enumerations\Layout::tryFrom((int) $iValue) ?? \Tachyon\Enumerations\Layout::SIDE_PREVIEW
			)->value;
		});

		$this->setSettingsFromParams($oSettings, 'EditorDefaultType', 'string');
		$this->setSettingsFromParams($oSettings, 'editorWysiwyg', 'string');
		$this->setSettingsFromParams($oSettings, 'requestReadReceipt', 'bool');
		$this->setSettingsFromParams($oSettings, 'requestDsn', 'bool');
		$this->setSettingsFromParams($oSettings, 'requireTLS', 'bool');
		$this->setSettingsFromParams($oSettings, 'pgpSign', 'bool');
		$this->setSettingsFromParams($oSettings, 'pgpEncrypt', 'bool');
		$this->setSettingsFromParams($oSettings, 'allowSpellcheck', 'bool');

		$this->setSettingsFromParams($oSettings, 'ViewHTML', 'bool');
		$this->setSettingsFromParams($oSettings, 'ViewImages', 'string');
		$this->setSettingsFromParams($oSettings, 'ViewImagesWhitelist', 'string');
		// Adding one sender merges here rather than the client sending the whole
		// list back. Every session reads the list once at login and never again, so
		// a whole list write replays a snapshot that can be days old and drops
		// whatever another session added meanwhile. That is why entries kept
		// disappearing for anyone using two machines. The textarea in settings
		// still overwrites, because editing it by hand means what it says.
		if ($this->HasActionParam('ViewImagesWhitelistAdd')) {
			$sAdd = \trim((string) $this->GetActionParam('ViewImagesWhitelistAdd', ''));
			if (\strlen($sAdd)) {
				$oSettings->SetConf('ViewImagesWhitelist', static::addToWhitelist(
					(string) $oSettings->GetConf('ViewImagesWhitelist', ''), $sAdd
				));
			}
		}
		$this->setSettingsFromParams($oSettings, 'RemoveColors', 'bool');
		$this->setSettingsFromParams($oSettings, 'AllowStyles', 'bool');
		$this->setSettingsFromParams($oSettings, 'ListInlineAttachments', 'bool');
		$this->setSettingsFromParams($oSettings, 'CollapseBlockquotes', 'bool');
		$this->setSettingsFromParams($oSettings, 'MaxBlockquotesLevel', 'int');
		$this->setSettingsFromParams($oSettings, 'simpleAttachmentsList', 'bool');
		$this->setSettingsFromParams($oSettings, 'listGrouped', 'bool');
		$this->setSettingsFromParams($oSettings, 'ContactsAutosave', 'bool');
		$this->setSettingsFromParams($oSettings, 'ContactsHideNoEmail', 'bool');
		$this->setSettingsFromParams($oSettings, 'calendarWeekNumbers', 'bool');
		$this->setSettingsFromParams($oSettings, 'calendarFirstDay', 'int');
		$this->setSettingsFromParams($oSettings, 'dateFormat', 'string');
		$this->setSettingsFromParams($oSettings, 'MainAccountName', 'string');
		$this->setSettingsFromParams($oSettings, 'DesktopNotifications', 'bool');
		$this->setSettingsFromParams($oSettings, 'SoundNotification', 'bool');
		$this->setSettingsFromParams($oSettings, 'NotificationSound', 'string');
		$this->setSettingsFromParams($oSettings, 'UseCheckboxesInList', 'bool');
		$this->setSettingsFromParams($oSettings, 'AllowDraftAutosave', 'bool');
		$this->setSettingsFromParams($oSettings, 'UndoSendDelay', 'int');
		$this->setSettingsFromParams($oSettings, 'AutoLogout', 'int');
		$this->setSettingsFromParams($oSettings, 'keyPassForget', 'int');
		$this->setSettingsFromParams($oSettings, 'messageNewWindow', 'bool');
		$this->setSettingsFromParams($oSettings, 'messageReadAuto', 'bool');
		$this->setSettingsFromParams($oSettings, 'MessageReadDelay', 'int');
		$this->setSettingsFromParams($oSettings, 'MsgDefaultAction', 'int');
		$this->setSettingsFromParams($oSettings, 'showNextMessage', 'bool');
		$this->setSettingsFromParams($oSettings, 'markdown', 'bool');

		$this->setSettingsFromParams($oSettings, 'Resizer4Width', 'int');
		$this->setSettingsFromParams($oSettings, 'Resizer5Width', 'int');
		$this->setSettingsFromParams($oSettings, 'Resizer5Height', 'int');

		$this->setSettingsFromParams($oSettingsLocal, 'defaultSort', 'string');
		$this->setSettingsFromParams($oSettingsLocal, 'UseThreads', 'bool');
		$this->setSettingsFromParams($oSettingsLocal, 'threadAlgorithm', 'string');
		$this->setSettingsFromParams($oSettingsLocal, 'ReplySameFolder', 'bool');
		$this->setSettingsFromParams($oSettingsLocal, 'HideUnsubscribed', 'bool');
		$this->setSettingsFromParams($oSettingsLocal, 'HideDeleted', 'bool');
		$this->setSettingsFromParams($oSettingsLocal, 'UnhideKolabFolders', 'bool');
		$this->setSettingsFromParams($oSettingsLocal, 'ShowUnreadCount', 'bool');
		$this->setSettingsFromParams($oSettingsLocal, 'CheckMailInterval', 'int');

		$bSaved = $oSettings->save() && $oSettingsLocal->save();

		// Handed back so the caller can replace its snapshot with what is actually
		// stored, rather than carrying on from the copy it had
		return $this->DefaultResponse($bSaved, array(
			'ViewImagesWhitelist' => (string) $oSettings->GetConf('ViewImagesWhitelist', '')
		));
	}

	public function DoQuota() : array
	{
		$oAccount = $this->initMailClientConnection();
		try
		{
			return $this->DefaultResponse($this->ImapClient()->QuotaRoot() ?: [0, 0, 0, 0]);
		}
		catch (\Throwable $oException)
		{
			throw new ClientException(Notifications::MailServerError, $oException);
		}
	}

	public function DoSuggestions() : array
	{
		$oAccount = $this->getAccountFromToken();

		$sQuery = \trim($this->GetActionParam('Query', ''));
		$iLimit = (int) $this->Config()->Get('contacts', 'suggestions_limit', 20);

		$this->Plugins()->RunHook('json.suggestions-input-parameters', array(&$sQuery, &$iLimit, $oAccount));

		$aResult = array();

		if ($oSuggestionsProvider = $this->SuggestionsProvider()) {
			$aResult = $oSuggestionsProvider->Process($oAccount, $sQuery, $iLimit);
		}

		return $this->DefaultResponse($aResult);
	}

	public function DoClearUserBackground() : array
	{
		if (!$this->GetCapa(Capa::USER_BACKGROUND)) {
			return $this->FalseResponse();
		}

		$oAccount = $this->getAccountFromToken();
		$oSettings = $this->SettingsProvider()->Load($oAccount);
		if ($oAccount && $oSettings) {
			$this->StorageProvider()->Clear($oAccount,
				\Tachyon\Providers\Storage\Enumerations\StorageType::CONFIG,
				'background'
			);

			$oSettings->SetConf('UserBackgroundName', '');
			$oSettings->SetConf('UserBackgroundHash', '');
		}

		return $this->DefaultResponse($oAccount && $oSettings ? $oSettings->save() : false);
	}

	/**
	 * One entry into a newline separated list, keeping what is there.
	 * Case insensitive on the comparison because a host is, and the entries can
	 * carry a suffix like "+dkim" that is not part of the host.
	 */
	private static function addToWhitelist(string $sList, string $sAdd) : string
	{
		$aLines = \preg_split('/\\R/', $sList, -1, PREG_SPLIT_NO_EMPTY) ?: array();
		$aLines = \array_map('trim', $aLines);
		$aLines = \array_filter($aLines, 'strlen');
		foreach ($aLines as $sLine) {
			if (0 === \strcasecmp($sLine, $sAdd)) {
				return \implode("\n", $aLines);
			}
		}
		$aLines[] = $sAdd;
		return \implode("\n", $aLines);
	}

	private function setSettingsFromParams(\Tachyon\Settings $oSettings, string $sConfigName, string $sType = 'string', ?callable $cCallback = null) : void
	{
		if ($this->HasActionParam($sConfigName)) {
			$sValue = $this->GetActionParam($sConfigName, '');
			switch ($sType)
			{
				default:
				case 'string':
					$sValue = (string) $sValue;
					if ($cCallback) {
						$sValue = $cCallback($sValue);
					}
					$oSettings->SetConf($sConfigName, (string) $sValue);
					break;

				case 'int':
					$iValue = (int) $sValue;
					if ($cCallback) {
						$sValue = $cCallback($iValue);
					}
					$oSettings->SetConf($sConfigName, $iValue);
					break;

				case 'bool':
					$oSettings->SetConf($sConfigName, !empty($sValue) && 'false' !== $sValue);
					break;
			}
		}
	}
}
