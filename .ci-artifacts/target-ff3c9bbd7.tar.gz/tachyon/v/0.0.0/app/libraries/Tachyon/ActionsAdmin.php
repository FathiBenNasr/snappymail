<?php

namespace Tachyon;

use Tachyon\Enumerations\PluginPropertyType;
use Tachyon\Exceptions\ClientException;

class ActionsAdmin extends Actions
{
	use Actions\AdminDomains;
	use Actions\AdminExtensions;

	public function DoAdminClearCache() : array
	{
		$this->Cacher()->GC(0);
		if (\is_dir(APP_PRIVATE_DATA . 'cache')) {
			\MailSo\Base\Utils::RecRmDir(APP_PRIVATE_DATA.'cache');
		}
		return $this->TrueResponse();
	}

	public function DoAdminSettingsGet() : array
	{
		$aConfig = $this->Config()->jsonSerialize();
		unset($aConfig['version']);
		$aConfig['logs']['time_zone'][1] = '';
		$aConfig['logs']['time_zone'][2] = \DateTimeZone::listIdentifiers();
		$aConfig['login']['sign_me_auto'][2] = ['DefaultOff','DefaultOn','Unused'];
		$aConfig['defaults']['view_images'][2] = ['ask','match','always'];
		return $this->DefaultResponse($aConfig);
	}

	public function DoAdminSettingsSet() : array
	{
		$oConfig = $this->Config();
		foreach ($this->GetActionParam('config', []) as $sSection => $aItems) {
			foreach ($aItems as $sKey => $mValue) {
				$oConfig->Set($sSection, $sKey, $mValue);
			}
		}
		return $this->DefaultResponse($oConfig->Save());
	}

	public function DoAdminSettingsUpdate() : array
	{
//		sleep(3);
//		return $this->DefaultResponse(false);

		$this->IsAdminLoggined();

		$oConfig = $this->Config();

		$self = $this;

		$this->setConfigFromParams($oConfig, 'language', 'webmail', 'language', 'string', function ($sLanguage) use ($self) {
			return $self->ValidateLanguage($sLanguage, '', false);
		});

		$this->setConfigFromParams($oConfig, 'languageAdmin', 'admin_panel', 'language', 'string', function ($sLanguage) use ($self) {
			return $self->ValidateLanguage($sLanguage, '', true);
		});

		$this->setConfigFromParams($oConfig, 'Theme', 'webmail', 'theme', 'string', function ($sTheme) use ($self) {
			return $self->ValidateTheme($sTheme);
		});

		$this->setConfigFromParams($oConfig, 'proxyExternalImages', 'labs', 'use_local_proxy_for_external_images', 'bool');
		$this->setConfigFromParams($oConfig, 'allowUpdate', 'admin_panel', 'allow_update', 'bool');
		$this->setConfigFromParams($oConfig, 'autoVerifySignatures', 'security', 'auto_verify_signatures', 'bool');

		$this->setConfigFromParams($oConfig, 'allowLanguagesOnSettings', 'webmail', 'allow_languages_on_settings', 'bool');
		$this->setConfigFromParams($oConfig, 'allowLanguagesOnLogin', 'login', 'allow_languages_on_login', 'bool');
		$this->setConfigFromParams($oConfig, 'attachmentLimit', 'webmail', 'attachment_size_limit', 'int');
		$this->setConfigFromParams($oConfig, 'messagesPerPage', 'webmail', 'messages_per_page', 'int');
		$this->setConfigFromParams($oConfig, 'messagesPerPageMax', 'webmail', 'messages_per_page_max', 'int');
		// setConfigFromParams only runs its callback for strings, so the floor
		// goes here. Ten is the lowest the settings screen offers.
		$oConfig->Set('webmail', 'messages_per_page', \max(10, (int) $oConfig->Get('webmail', 'messages_per_page', 20)));
		$oConfig->Set('webmail', 'messages_per_page_max', \max(10, (int) $oConfig->Get('webmail', 'messages_per_page_max', 100)));

		$this->setConfigFromParams($oConfig, 'loginDefaultDomain', 'login', 'default_domain', 'string');

		$this->setConfigFromParams($oConfig, 'contactsEnable', 'contacts', 'enable', 'bool');
		$this->setConfigFromParams($oConfig, 'contactsSync', 'contacts', 'allow_sync', 'bool');
		$this->setConfigFromParams($oConfig, 'contactsPdoDsn', 'contacts', 'pdo_dsn', 'string');
		$this->setConfigFromParams($oConfig, 'contactsPdoUser', 'contacts', 'pdo_user', 'string');
		$this->setConfigFromParams($oConfig, 'contactsPdoPassword', 'contacts', 'pdo_password', 'dummy');
		$this->setConfigFromParams($oConfig, 'contactsMySQLSSLCA', 'contacts', 'mysql_ssl_ca', 'string');
		$this->setConfigFromParams($oConfig, 'contactsMySQLSSLVerify', 'contacts', 'mysql_ssl_verify', 'bool');
		$this->setConfigFromParams($oConfig, 'contactsMySQLSSLCiphers', 'contacts', 'mysql_ssl_ciphers', 'string');
		$this->setConfigFromParams($oConfig, 'contactsSQLiteGlobal', 'contacts', 'sqlite_global', 'bool');
		$this->setConfigFromParams($oConfig, 'contactsSuggestionsLimit', 'contacts', 'suggestions_limit', 'int');
		$this->setConfigFromParams($oConfig, 'contactsComposeLimit', 'contacts', 'compose_recipients_limit', 'int');
		$this->setConfigFromParams($oConfig, 'contactsBccLimit', 'contacts', 'bcc_recommend_limit', 'int');
		$this->setConfigFromParams($oConfig, 'contactsPdoType', 'contacts', 'type', 'string', function ($sType) use ($self) {
			return Providers\AddressBook\PdoAddressBook::validPdoType($sType);
		});

		$this->setConfigFromParams($oConfig, 'calendarEnable', 'calendar', 'enable', 'bool');
		$this->setConfigFromParams($oConfig, 'calendarSync', 'calendar', 'allow_sync', 'bool');
		$this->setConfigFromParams($oConfig, 'calendarSyncInterval', 'calendar', 'sync_interval', 'int');
		$this->setConfigFromParams($oConfig, 'calendarPdoDsn', 'calendar', 'pdo_dsn', 'string');
		$this->setConfigFromParams($oConfig, 'calendarPdoUser', 'calendar', 'pdo_user', 'string');
		$this->setConfigFromParams($oConfig, 'calendarPdoPassword', 'calendar', 'pdo_password', 'dummy');
		$this->setConfigFromParams($oConfig, 'calendarMySQLSSLCA', 'calendar', 'mysql_ssl_ca', 'string');
		$this->setConfigFromParams($oConfig, 'calendarMySQLSSLVerify', 'calendar', 'mysql_ssl_verify', 'bool');
		$this->setConfigFromParams($oConfig, 'calendarMySQLSSLCiphers', 'calendar', 'mysql_ssl_ciphers', 'string');
		$this->setConfigFromParams($oConfig, 'calendarSQLiteGlobal', 'calendar', 'sqlite_global', 'bool');
		$this->setConfigFromParams($oConfig, 'calendarMaxRangeDays', 'calendar', 'max_range_days', 'int');
		$this->setConfigFromParams($oConfig, 'calendarMaxOccurrences', 'calendar', 'max_occurrences', 'int');
		$this->setConfigFromParams($oConfig, 'calendarPdoType', 'calendar', 'type', 'string', function ($sType) use ($self) {
			return Providers\Calendar\PdoCalendar::validPdoType($sType);
		});

		$this->setConfigFromParams($oConfig, 'logsEnable', 'logs', 'enable', 'bool');
		$this->setConfigFromParams($oConfig, 'logsPath', 'logs', 'path', 'string');
		$this->setConfigFromParams($oConfig, 'logsFilename', 'logs', 'filename', 'string');
		$this->setConfigFromParams($oConfig, 'logsLevel', 'logs', 'level', 'int');
		$this->setConfigFromParams($oConfig, 'logsTimeZone', 'logs', 'time_zone', 'string');
		$this->setConfigFromParams($oConfig, 'logsHidePasswords', 'logs', 'hide_passwords', 'bool');
		$this->setConfigFromParams($oConfig, 'logsAuthLogging', 'logs', 'auth_logging', 'bool');
		$this->setConfigFromParams($oConfig, 'logsAuthLoggingFilename', 'logs', 'auth_logging_filename', 'string');
		$this->setConfigFromParams($oConfig, 'logsAuthLoggingFormat', 'logs', 'auth_logging_format', 'string');
		$this->setConfigFromParams($oConfig, 'logsSyslogIdent', 'logs', 'syslog_ident', 'string');
		$this->setConfigFromParams($oConfig, 'loginLogoMode', 'webmail', 'login_logo_mode', 'string');
		$this->setConfigFromParams($oConfig, 'faviconMode', 'webmail', 'favicon_mode', 'string');
		$this->setConfigFromParams($oConfig, 'loginFooter', 'webmail', 'login_footer', 'string');
		$this->setConfigFromParams($oConfig, 'debugEnable', 'debug', 'enable', 'bool');
		$this->setConfigFromParams($oConfig, 'debugJavascript', 'debug', 'javascript', 'bool');
		$this->setConfigFromParams($oConfig, 'debugCss', 'debug', 'css', 'bool');

		$this->setConfigFromParams($oConfig, 'CapaAdditionalAccounts', 'webmail', 'allow_additional_accounts', 'bool');
		$this->setConfigFromParams($oConfig, 'CapaIdentities', 'webmail', 'allow_additional_identities', 'bool');
		$this->setConfigFromParams($oConfig, 'CapaAttachmentThumbnails', 'interface', 'show_attachment_thumbnail', 'bool');
		$this->setConfigFromParams($oConfig, 'CapaThemes', 'webmail', 'allow_themes', 'bool');
		$this->setConfigFromParams($oConfig, 'CapaUserBackground', 'webmail', 'allow_user_background', 'bool');
		$this->setConfigFromParams($oConfig, 'capaGnuPG', 'security', 'gnupg', 'bool');
		$this->setConfigFromParams($oConfig, 'capaOpenPGP', 'security', 'openpgp', 'bool');

		$this->setConfigFromParams($oConfig, 'determineUserLanguage', 'login', 'determine_user_language', 'bool');
		$this->setConfigFromParams($oConfig, 'determineUserDomain', 'login', 'determine_user_domain', 'bool');

		$this->setConfigFromParams($oConfig, 'title', 'webmail', 'title', 'string');
		$this->setConfigFromParams($oConfig, 'loadingDescription', 'webmail', 'loading_description', 'string');
		$this->setConfigFromParams($oConfig, 'faviconUrl', 'webmail', 'favicon_url', 'string');

		$this->setConfigFromParams($oConfig, 'pluginsEnable', 'plugins', 'enable', 'bool');

		return $this->DefaultResponse($oConfig->Save());
	}

	/**
	 * Which of the two login logos an upload or delete is aimed at.
	 * 'dark' means the artwork for a dark background, so light ink.
	 */
	private function logoVariant() : string
	{
		return 'dark' === $this->GetActionParam('variant', '') ? 'dark' : 'light';
	}

	private function logoConfigKey(string $sVariant) : string
	{
		return 'dark' === $sVariant ? 'logo_file_dark' : 'logo_file';
	}

	/**
	 * Everything the logo and the favicon uploads have in common: sniff the
	 * type, make the folder, clear what was there, and store under a name
	 * carrying a digest of the contents so a replacement is never served from
	 * the cache of the file it replaced.
	 *
	 * @param string $sPrefix  filename stem, also the glob used to clear old ones
	 * @param array  $aExtMap  accepted mime types mapped to the extension to store
	 * @return string  the stored filename, or '' on any failure
	 */
	private function storeBrandingUpload(string $sPrefix, array $aExtMap, string $sLabel) : string
	{
		if (empty($_FILES['logo']['tmp_name'])) {
			$this->logWrite("{$sLabel}: no file in \$_FILES[logo]", \LOG_WARNING);
			return '';
		}
		$tmp = $_FILES['logo']['tmp_name'];
		$mime = \Tachyon\Util\File\MimeType::fromFile($tmp);
		// finfo and mime_content_type routinely call an SVG text/xml or text/html,
		// and an .ico anything from image/vnd.microsoft.icon to application/octet-stream
		if (!$mime || \in_array($mime, ['text/xml', 'text/html', 'application/xml', 'application/octet-stream'])) {
			$ext = \strtolower(\pathinfo($_FILES['logo']['name'] ?? '', PATHINFO_EXTENSION));
			if ('svg' === $ext) {
				$mime = 'image/svg+xml';
			} else if ('ico' === $ext) {
				$mime = 'image/x-icon';
			}
		}
		if (!isset($aExtMap[$mime])) {
			$this->logWrite("{$sLabel}: rejected mime '{$mime}'", \LOG_WARNING);
			return '';
		}
		$dir = APP_PRIVATE_DATA . 'branding/';
		if (!\is_dir($dir) && !\mkdir($dir, 0755, true)) {
			$this->logWrite("{$sLabel}: cannot create directory {$dir}", \LOG_ERR);
			return '';
		}
		foreach (\glob($dir . $sPrefix . '*.*') ?: [] as $old) {
			\unlink($old);
		}
		$filename = $sPrefix . \substr(\sha1_file($tmp) ?: \bin2hex(\random_bytes(4)), 0, 8)
			. '.' . $aExtMap[$mime];
		if (!\move_uploaded_file($tmp, $dir . $filename)) {
			$this->logWrite("{$sLabel}: move_uploaded_file failed to {$dir}{$filename}", \LOG_ERR);
			return '';
		}
		return $filename;
	}

	public function DoAdminUploadLogo(): array
	{
		$sVariant = $this->logoVariant();
		$filename = $this->storeBrandingUpload('logo-' . $sVariant . '-', [
			'image/png'     => 'png',
			'image/jpeg'    => 'jpg',
			'image/gif'     => 'gif',
			'image/svg+xml' => 'svg',
			'image/webp'    => 'webp',
		], 'UploadLogo');
		if (!\strlen($filename)) {
			return $this->FalseResponse(__FUNCTION__);
		}
		// Anything from before the light/dark split, which was a bare logo.<ext>
		if ('light' === $sVariant) {
			foreach (\glob(APP_PRIVATE_DATA . 'branding/logo.*') ?: [] as $old) {
				\unlink($old);
			}
		}
		$oConfig = $this->Config();
		$oConfig->Set('webmail', $this->logoConfigKey($sVariant), $filename);
		$oConfig->Save();
		return $this->DefaultResponse($filename);
	}

	public function DoAdminUploadFavicon(): array
	{
		// ICO and SVG alongside the raster types. SVG is the one worth
		// recommending: it is the only one that scales to every slot the browser
		// asks for, and the only one that can follow the colour scheme.
		$filename = $this->storeBrandingUpload('favicon-', [
			'image/png'            => 'png',
			'image/svg+xml'        => 'svg',
			'image/x-icon'         => 'ico',
			'image/vnd.microsoft.icon' => 'ico',
			'image/gif'            => 'gif',
			'image/webp'           => 'webp',
		], 'UploadFavicon');
		if (!\strlen($filename)) {
			return $this->FalseResponse(__FUNCTION__);
		}
		$oConfig = $this->Config();
		$oConfig->Set('webmail', 'favicon_file', $filename);
		$oConfig->Save();
		return $this->DefaultResponse($filename);
	}

	public function DoAdminDeleteFavicon(): array
	{
		$oConfig = $this->Config();
		if ($oConfig->Get('webmail', 'favicon_file', '')) {
			foreach (\glob(APP_PRIVATE_DATA . 'branding/favicon-*.*') ?: [] as $old) {
				\unlink($old);
			}
			$oConfig->Set('webmail', 'favicon_file', '');
			$oConfig->Save();
		}
		return $this->DefaultResponse(true);
	}

	public function DoAdminDeleteLogo(): array
	{
		$oConfig = $this->Config();
		$sVariant = $this->logoVariant();
		$sKey = $this->logoConfigKey($sVariant);
		$filename = $oConfig->Get('webmail', $sKey, '');
		if ($filename) {
			$dir = APP_PRIVATE_DATA . 'branding/';
			$aOld = \glob($dir . 'logo-' . $sVariant . '-*.*') ?: [];
			if ('light' === $sVariant) {
				// clears anything left by the pre split naming too
				$aOld = \array_merge($aOld, \glob($dir . 'logo.*') ?: []);
			}
			foreach ($aOld as $old) {
				\unlink($old);
			}
			$oConfig->Set('webmail', $sKey, '');
			$oConfig->Save();
		}
		return $this->DefaultResponse(true);
	}

	/**
	 * @throws \MailSo\RuntimeException
	 */
	public function DoAdminLogin() : array
	{
		$sLogin = trim($this->GetActionParam('Login', ''));
		$oPassword = new \Tachyon\Util\SensitiveString($this->GetActionParam('Password', ''));

		$totp = $this->Config()->Get('security', 'admin_totp', '');

		// Brute-force backstop: 5 attempts per IP per 15 minutes, after which
		// the endpoint stops evaluating credentials until the window expires.
		// The locked-out response is identical to a failed login (same error
		// and delay), so the lockout state itself is not observable.
		// The check-and-increment runs under a per-IP lock: without it,
		// concurrent requests read the same counter value and each write
		// back count+1, multiplying the attempt budget by the attacker's
		// concurrency (lost-update race). A successful login clears the
		// counter below.
		$sIp = $this->Http()->GetClientIp($this->oConfig->Get('labs', 'http_client_ip_check_proxy', false));
		$sFaultKey = KeyPathHelper::AdminLoginFaults($sIp);
		$oCacher = $this->Cacher(null, true);
		$bLockedOut = true; // fail closed if the counter cannot be updated
		$rLock = \fopen(\sys_get_temp_dir().'/tachyon-adminlogin-'.\md5($sIp).'.lock', 'c');
		if (\is_resource($rLock) && \flock($rLock, LOCK_EX)) {
			$iFaults = 0;
			$iFirstFault = 0;
			$sFaults = $oCacher->Get($sFaultKey);
			if (\is_string($sFaults) && 2 === \sscanf($sFaults, '%d|%d', $iFaults, $iFirstFault)
				&& \time() - $iFirstFault > 900) {
				$iFaults = 0; // window expired
				$iFirstFault = 0;
			}
			if ($iFaults < 5) {
				$oCacher->Set($sFaultKey, ($iFaults + 1).'|'.($iFaults ? $iFirstFault : \time()));
				$bLockedOut = false;
			}
			\flock($rLock, LOCK_UN);
		}
		if (\is_resource($rLock)) {
			\fclose($rLock);
		}
		if ($bLockedOut) {
			$this->LoggerAuthHelper(null, $sLogin, true);
			$this->loginErrorDelay();
			throw new ClientException(Notifications::AuthError);
		}

		// \explode(':',`getent shadow root`)[1];
		if (!\strlen($sLogin) || !\strlen($oPassword) ||
			!$this->Config()->Get('security', 'allow_admin_panel', true) ||
			$sLogin !== $this->Config()->Get('security', 'admin_login', '') ||
			!$this->Config()->ValidatePassword($oPassword)
			|| ($totp && !\Tachyon\Util\TOTP::Verify($totp, $this->GetActionParam('TOTP', ''))))
		{
			$this->LoggerAuthHelper(null, $sLogin, true);
			$this->loginErrorDelay();
			throw new ClientException(Notifications::AuthError);
		}

		$oCacher->Delete($sFaultKey);

		$sToken = $this->setAdminAuthToken();

		return $this->DefaultResponse($sToken ? $this->AppData(true) : false);
	}

	public function DoAdminLogout() : array
	{
		$sAdminKey = $this->getAdminAuthKey();
		if ($sAdminKey) {
			$this->Cacher(null, true)->Delete(KeyPathHelper::SessionAdminKey($sAdminKey));
		}
		\Tachyon\Util\Cookies::clear(static::$AUTH_ADMIN_TOKEN_KEY);
		return $this->TrueResponse();
	}

	public function DoAdminContactsTest() : array
	{
		$this->IsAdminLoggined();

		$oConfig = $this->Config();
		$this->setConfigFromParams($oConfig, 'PdoDsn', 'contacts', 'pdo_dsn', 'string');
		$this->setConfigFromParams($oConfig, 'PdoUser', 'contacts', 'pdo_user', 'string');
		$this->setConfigFromParams($oConfig, 'PdoPassword', 'contacts', 'pdo_password', 'dummy');
		$this->setConfigFromParams($oConfig, 'PdoType', 'contacts', 'type', 'string', function ($sType) {
			return Providers\AddressBook\PdoAddressBook::validPdoType($sType);
		});
		$this->setConfigFromParams($oConfig, 'MySQLSSLCA', 'contacts', 'mysql_ssl_ca', 'string');
		$this->setConfigFromParams($oConfig, 'MySQLSSLVerify', 'contacts', 'mysql_ssl_verify', 'bool');
		$this->setConfigFromParams($oConfig, 'MySQLSSLCiphers', 'contacts', 'mysql_ssl_ciphers', 'string');
		$this->setConfigFromParams($oConfig, 'SQLiteGlobal', 'contacts', 'sqlite_global', 'bool');

		$sTestMessage = '';
		try {
			$AddressBook = new Providers\AddressBook(new Providers\AddressBook\PdoAddressBook());
			$AddressBook->SetLogger($this->oLogger);
			$sTestMessage = $AddressBook->Test();
		} catch (\Throwable $e) {
			\Tachyon\Util\LOG::error('AddressBook', $e->getMessage()."\n".$e->getTraceAsString());
			$sTestMessage = $e->getMessage();
		}

		return $this->DefaultResponse(array(
			'Result' => '' === $sTestMessage,
			'Message' => \MailSo\Base\Utils::Utf8Clear($sTestMessage)
		));
	}

	public function DoAdminCalendarTest() : array
	{
		$this->IsAdminLoggined();

		$oConfig = $this->Config();
		$this->setConfigFromParams($oConfig, 'PdoDsn', 'calendar', 'pdo_dsn', 'string');
		$this->setConfigFromParams($oConfig, 'PdoUser', 'calendar', 'pdo_user', 'string');
		$this->setConfigFromParams($oConfig, 'PdoPassword', 'calendar', 'pdo_password', 'dummy');
		$this->setConfigFromParams($oConfig, 'PdoType', 'calendar', 'type', 'string', function ($sType) {
			return Providers\Calendar\PdoCalendar::validPdoType($sType);
		});
		$this->setConfigFromParams($oConfig, 'MySQLSSLCA', 'calendar', 'mysql_ssl_ca', 'string');
		$this->setConfigFromParams($oConfig, 'MySQLSSLVerify', 'calendar', 'mysql_ssl_verify', 'bool');
		$this->setConfigFromParams($oConfig, 'MySQLSSLCiphers', 'calendar', 'mysql_ssl_ciphers', 'string');
		$this->setConfigFromParams($oConfig, 'SQLiteGlobal', 'calendar', 'sqlite_global', 'bool');

		$sTestMessage = '';
		try {
			$oCalendar = new Providers\Calendar(new Providers\Calendar\PdoCalendar());
			$sTestMessage = $oCalendar->Test();
		} catch (\Throwable $e) {
			\Tachyon\Util\Log::error('Calendar', $e->getMessage()."\n".$e->getTraceAsString());
			$sTestMessage = $e->getMessage();
		}

		return $this->DefaultResponse(array(
			'Result' => '' === $sTestMessage,
			'Message' => \MailSo\Base\Utils::Utf8Clear($sTestMessage)
		));
	}

	public function DoAdminPasswordUpdate() : array
	{
		$this->IsAdminLoggined();

		$bResult = false;
		$oConfig = $this->Config();

		$oPassword = new \Tachyon\Util\SensitiveString($this->GetActionParam('Password', ''));

		$oNewPassword = new \Tachyon\Util\SensitiveString($this->GetActionParam('newPassword', ''));

		$passfile = APP_PRIVATE_DATA.'admin_password.txt';

		if ($oConfig->ValidatePassword($oPassword)) {
			$sLogin = \trim($this->GetActionParam('Login', ''));
			if (\strlen($sLogin)) {
				$oConfig->Set('security', 'admin_login', $sLogin);
			}

			// Two factor is only touched when it is actually being changed, and
			// turning it on has to be proven first.
			//
			// This used to write whatever the form posted, every time. The
			// Generate button fills the field client side just to draw a QR code,
			// so saving a new password after pressing it silently required codes
			// for a secret that had never been scanned, and locked the admin out
			// with no warning and no way back except editing application.ini.
			$sCurrentTOTP = (string) $oConfig->Get('security', 'admin_totp', '');
			$sNewTOTP = \trim($this->GetActionParam('TOTP', ''));
			if ($sNewTOTP !== $sCurrentTOTP) {
				if (\strlen($sNewTOTP)) {
					// Enabling: the code proves the secret was scanned and that
					// this admin can still get in afterwards
					if (!\Tachyon\Util\TOTP::Verify($sNewTOTP, \trim($this->GetActionParam('TOTPCode', '')))) {
						throw new ClientException(Notifications::AuthError, null, 'TOTP code does not match the secret');
					}
				}
				// Clearing needs nothing beyond the password already checked above
				$oConfig->Set('security', 'admin_totp', $sNewTOTP);
			}

			if (\strlen($oNewPassword)) {
				$oConfig->SetPassword($oNewPassword);
				if (\is_file($passfile) && \trim(\file_get_contents($passfile)) !== (string) $oNewPassword) {
					\unlink($passfile);
				}
			}

			$bResult = $oConfig->Save();
		}

		return $this->DefaultResponse($bResult
			? array('Weak' => \is_file($passfile))
			: false);
	}

	// /?admin/Backup
	public function DoAdminBackup() : void
	{
		try {
			$this->IsAdminLoggined();
			$name = 'tachyon-backup-' . \date('YmdHis');
			$zip = new \Tachyon\Util\Stream\ZIP('php://output');
			$zip->pushHttpHeaders($name);
			foreach (['configs', 'domains', 'plugins', 'storage'] as $dir) {
				$sDir = APP_PRIVATE_DATA . $dir;
				if (\is_dir($sDir)) {
					$zip->addRecursive($sDir, $dir);
				}
			}
			if (\is_readable(APP_PRIVATE_DATA . 'AddressBook.sqlite')) {
				$zip->addFile(APP_PRIVATE_DATA . 'AddressBook.sqlite', 'AddressBook.sqlite');
			}
			$zip->close();
		} catch (\Throwable $e) {
			if (102 == $e->getCode()) {
				\MailSo\Base\Http::StatusHeader(403);
			}
			echo $e->getMessage();
		}
		exit;
	}

	public function DoAdminInfo() : array
	{
		$this->IsAdminLoggined();

		$oConfig = $this->Config();
		$info = \Tachyon\Util\Repository::getLatestCoreInfo();

		$sVersion = $info?->version ?? '';

		// Why the update cannot run, for the admin to read. Mirrors the checks in
		// Repository::canUpdateCore, which returns a bare bool.
		$aWarnings = [];
		if (!$oConfig->Get('admin_panel', 'allow_update', false)) {
			$aWarnings[] = 'Updating from the admin panel is turned off';
		}
		if (!\version_compare(APP_VERSION, '2.0', '>')) {
			$aWarnings[] = 'Version ' . APP_VERSION . ' is too old to update in place';
		}
		// Not writable almost always means the files belong to a package manager
		// or to root, in which case updating is that installer's job and doing it
		// here would be overwritten or would break the package database
		if (!\is_writable(\dirname(APP_VERSION_ROOT_PATH))) {
			$aWarnings[] = 'Not writable: ' . \dirname(APP_VERSION_ROOT_PATH);
		}
		if (!\is_writable(APP_INDEX_ROOT_PATH . 'index.php')) {
			$aWarnings[] = 'Not writable: ' . APP_INDEX_ROOT_PATH . 'index.php';
		}

		$aResult = [
			'system' => [
				'load' => \is_callable('sys_getloadavg') ? \sys_getloadavg() : null
			],
			'core' => [
				 'updatable' => \Tachyon\Util\Repository::canUpdateCore(),
				 'version' => $sVersion,
				 'versionCompare' => \version_compare(APP_VERSION, $sVersion),
				 'warnings' => $aWarnings
			],
			'php' => [
				[
					'name' => 'PHP ' . PHP_VERSION,
					'loaded' => true,
					'version' => PHP_VERSION
				],
				[
					'name' => 'PHP 64bit',
					'loaded' => PHP_INT_SIZE == 8,
					'version' => PHP_INT_SIZE
				]
			]
		];

		foreach (['APCu', 'cURL','Fileinfo','iconv','intl','LDAP','redis','Tidy','uuid','Zip'] as $name) {
			$aResult['php'][] = [
				'name' => $name,
				'loaded' => \extension_loaded(\strtolower($name)),
				'version' => \phpversion($name)
			];
		}

		$aResult['php'][] = [
			'name' => 'Phar',
			'loaded' => \class_exists('PharData'),
			'version' => \phpversion('phar')
		];

		$aResult['php'][] = [
			'name' => 'Contacts database:',
			'loaded' => \extension_loaded('pdo_mysql') || \extension_loaded('pdo_pgsql') || \extension_loaded('pdo_sqlite'),
			'version' => 0
		];
		foreach (['pdo_mysql','pdo_pgsql','pdo_sqlite'] as $name) {
			$aResult['php'][] = [
				'name' => "- {$name}",
				'loaded' => \extension_loaded(\strtolower($name)),
				'version' => \phpversion($name)
			];
		}

		$aResult['php'][] = [
			'name' => 'Crypt:',
			'loaded' => true,
			'version' => 0
		];
		foreach (['Sodium','OpenSSL','XXTEA','GnuPG'] as $name) {
			$aResult['php'][] = [
				'name' => '- ' . (('OpenSSL' === $name && \defined('OPENSSL_VERSION_TEXT')) ? OPENSSL_VERSION_TEXT : $name),
				'loaded' => \extension_loaded(\strtolower($name)),
				'version' => \phpversion($name)
			];
		}

		$aResult['php'][] = [
			'name' => 'Image processing:',
			'loaded' => \extension_loaded('gd') || \extension_loaded('gmagick') || \extension_loaded('imagick'),
			'version' => 0
		];
		foreach (['GD','Gmagick','Imagick'] as $name) {
			$aResult['php'][] = [
				'name' => "- {$name}",
				'loaded' => \extension_loaded(\strtolower($name)),
				'version' => \phpversion($name)
			];
		}

		return $this->DefaultResponse($aResult);
	}

	public function DoAdminUpgradeCore() : array
	{
		\header('Connection: close');
		return $this->DefaultResponse(\Tachyon\Util\Upgrade::core());
	}

	public function DoAdminVersionsList() : array
	{
		return $this->DefaultResponse(array(
			'Versions' => \Tachyon\Util\Versions::installed()
		));
	}

	/**
	 * Deletes dormant application directories left behind by past upgrades.
	 *
	 * Takes product and version tokens, never a path. Versions::remove()
	 * rebuilds the path itself and checks it against a fresh scan, so a request
	 * cannot name anything the filesystem does not already list.
	 *
	 * One entry failing does not abandon the rest: a tree with the wrong
	 * ownership is common and should not block the ones that would delete
	 * cleanly, so each result is reported separately.
	 */
	public function DoAdminVersionsDelete() : array
	{
		$aVersions = $this->GetActionParam('Versions', null);
		if (!\is_array($aVersions)) {
			throw new ClientException(Notifications::InvalidInputArgument);
		}

		$iDeleted = 0;
		$aErrors = array();
		foreach ($aVersions as $aItem) {
			$sProduct = \is_array($aItem) ? (string) ($aItem['product'] ?? '') : '';
			$sVersion = \is_array($aItem) ? (string) ($aItem['version'] ?? '') : '';
			try {
				\Tachyon\Util\Versions::remove($sProduct, $sVersion);
				++$iDeleted;
				$this->logWrite("Removed {$sProduct} {$sVersion}", \LOG_NOTICE, 'CLEANUP');
			} catch (\Throwable $oException) {
				$aErrors[] = "{$sProduct} {$sVersion}: " . $oException->getMessage();
				$this->logWrite(
					"Refused to remove {$sProduct} {$sVersion}: " . $oException->getMessage(),
					\LOG_WARNING, 'CLEANUP'
				);
			}
		}

		// No version list here on purpose. Rebuilding it means measuring every
		// remaining tree, which doubled the cost of a delete, and the client
		// re-reads the list once when its queue drains.
		return $this->DefaultResponse(array(
			'Deleted' => $iDeleted,
			'Errors' => $aErrors
		));
	}

	public function DoAdminQRCode() : array
	{
		$user = (string) $this->GetActionParam('username', '');
		$secret = (string) $this->GetActionParam('TOTP', '');

		/**
		 * The issuer is the admin's own webmail title, it appears twice in the
		 * URI, and rawurlencode turns one non-ASCII character into six bytes. A
		 * long Cyrillic title therefore ran past what any QR code we can produce
		 * holds and two factor enrolment failed outright (#80). The title is
		 * only a label in the authenticator, so a shortened one is far better
		 * than no QR code, and the product name is the last resort.
		 */
		$sTitle = \trim((string) API::Config()->Get('webmail', 'title', 'Tachyon'));
		foreach ([$sTitle, \mb_substr($sTitle, 0, 16), \mb_substr($sTitle, 0, 8), 'Tachyon'] as $sCandidate) {
			if (!\strlen($sCandidate)) {
				continue;
			}
			$issuer = \rawurlencode($sCandidate);
			try {
				$QR = \Tachyon\Util\QRCode::getMinimumQRCode(
					"otpauth://totp/{$issuer}:{$user}?secret={$secret}&issuer={$issuer}",
//					"otpauth://totp/{$user}?secret={$secret}",
					\Tachyon\Util\QRCode::ERROR_CORRECT_LEVEL_M
				);
				return $this->DefaultResponse($QR->__toString());
			} catch (\OutOfBoundsException $oException) {
				$this->logWrite(
					'TOTP QR code too long with this issuer, shortening: ' . $oException->getMessage(),
					\LOG_NOTICE
				);
			}
		}

		throw new \Exception('Could not build a TOTP QR code');
	}

	private function setAdminAuthToken() : string
	{
		$sRand = \MailSo\Base\Utils::Sha1Rand();
		if (!$this->Cacher(null, true)->Set(KeyPathHelper::SessionAdminKey($sRand), \time())) {
			throw new \RuntimeException('Failed to store admin token');
		}
		$sToken = Utils::EncodeKeyValuesQ(array('token', $sRand));
		if (!$sToken) {
			throw new \RuntimeException('Failed to encode admin token');
		}
		\Tachyon\Util\Cookies::set(static::$AUTH_ADMIN_TOKEN_KEY, $sToken);
		return $sToken;
	}

	private function setConfigFromParams(Config\Application $oConfig, string $sParamName, string $sConfigSector, string $sConfigName, string $sType = 'string', ?callable $mStringCallback = null): void
	{
		if ($this->HasActionParam($sParamName)) {
			$sValue = $this->GetActionParam($sParamName, '');
			switch ($sType) {
				default:
				case 'string':
					$sValue = (string)$sValue;
					if ($mStringCallback && is_callable($mStringCallback)) {
						$sValue = $mStringCallback($sValue);
					}

					$oConfig->Set($sConfigSector, $sConfigName, $sValue);
					break;

				case 'dummy':
					$sValue = (string) $this->GetActionParam($sParamName, static::APP_DUMMY);
					if (static::APP_DUMMY !== $sValue) {
						$oConfig->Set($sConfigSector, $sConfigName, $sValue);
					}
					break;

				case 'int':
					$iValue = (int)$sValue;
					$oConfig->Set($sConfigSector, $sConfigName, $iValue);
					break;

				case 'bool':
					$oConfig->Set($sConfigSector, $sConfigName, !empty($sValue) && 'false' !== $sValue);
					break;
			}
		}
	}

	public static function AdminAppData(Actions $oActions, array &$aResult): void
	{
		$oConfig = $oActions->Config();
		$aResult['Admin'] = [
			'host' => '' !== $oConfig->Get('admin_panel', 'host', ''),
			'path' => $oConfig->Get('admin_panel', 'key', '') ?: 'admin',
			'allowed' => (bool)$oConfig->Get('security', 'allow_admin_panel', true)
		];

		// Outside the Auth gate on purpose: the admin login screen draws the same
		// logo the user login does, and it is by definition not logged in yet.
		$aResult['logoFile'] = $oConfig->Get('webmail', 'logo_file', '');
		$aResult['logoFileDark'] = $oConfig->Get('webmail', 'logo_file_dark', '');
		$aResult['loginLogoMode'] = $oConfig->Get('webmail', 'login_logo_mode', 'default');

		$aResult['Auth'] = $oActions->IsAdminLoggined(false);
		if ($aResult['Auth']) {
			$aResult['adminLogin'] = (string)$oConfig->Get('security', 'admin_login', '');
			$aResult['adminTOTP'] = (string)$oConfig->Get('security', 'admin_totp', '');
			$aResult['pluginsEnable'] = (bool)$oConfig->Get('plugins', 'enable', false);
			$aResult['allowUpdate'] = (bool)$oConfig->Get('admin_panel', 'allow_update', false);

			$aResult['loginDefaultDomain'] = $oConfig->Get('login', 'default_domain', '');
			$aResult['determineUserLanguage'] = (bool)$oConfig->Get('login', 'determine_user_language', true);
			$aResult['determineUserDomain'] = (bool)$oConfig->Get('login', 'determine_user_domain', false);

			$aResult['supportedPdoDrivers'] = \Tachyon\Pdo\Base::getAvailableDrivers();

			$aResult['contactsEnable'] = (bool)$oConfig->Get('contacts', 'enable', false);
			$aResult['contactsSync'] = (bool)$oConfig->Get('contacts', 'allow_sync', false);
			$aResult['contactsPdoType'] = Providers\AddressBook\PdoAddressBook::validPdoType($oConfig->Get('contacts', 'type', 'sqlite'));
			$aResult['contactsPdoDsn'] = (string)$oConfig->Get('contacts', 'pdo_dsn', '');
			$aResult['contactsPdoType'] = (string)$oConfig->Get('contacts', 'type', '');
			$aResult['contactsPdoUser'] = (string)$oConfig->Get('contacts', 'pdo_user', '');
			$aResult['contactsPdoPassword'] = static::APP_DUMMY;
			$aResult['contactsMySQLSSLCA'] = (string) $oConfig->Get('contacts', 'mysql_ssl_ca', '');
			$aResult['contactsMySQLSSLVerify'] = !!$oConfig->Get('contacts', 'mysql_ssl_verify', true);
			$aResult['contactsMySQLSSLCiphers'] = (string) $oConfig->Get('contacts', 'mysql_ssl_ciphers', '');
			$aResult['contactsSQLiteGlobal'] = !!$oConfig->Get('contacts', 'sqlite_global', \is_file(APP_PRIVATE_DATA . '/AddressBook.sqlite'));
			$aResult['contactsSuggestionsLimit'] = (int)$oConfig->Get('contacts', 'suggestions_limit', 20);
			$aResult['contactsComposeLimit'] = (int)$oConfig->Get('contacts', 'compose_recipients_limit', 100);
			$aResult['contactsBccLimit'] = (int)$oConfig->Get('contacts', 'bcc_recommend_limit', 20);

			$aResult['calendarEnable'] = (bool)$oConfig->Get('calendar', 'enable', false);
			$aResult['calendarSync'] = (bool)$oConfig->Get('calendar', 'allow_sync', true);
			$aResult['calendarSyncInterval'] = (int)$oConfig->Get('calendar', 'sync_interval', 20);
			$aResult['calendarPdoType'] = Providers\Calendar\PdoCalendar::validPdoType($oConfig->Get('calendar', 'type', 'sqlite'));
			$aResult['calendarPdoDsn'] = (string)$oConfig->Get('calendar', 'pdo_dsn', '');
			$aResult['calendarPdoUser'] = (string)$oConfig->Get('calendar', 'pdo_user', '');
			$aResult['calendarPdoPassword'] = static::APP_DUMMY;
			$aResult['calendarMySQLSSLCA'] = (string)$oConfig->Get('calendar', 'mysql_ssl_ca', '');
			$aResult['calendarMySQLSSLVerify'] = !!$oConfig->Get('calendar', 'mysql_ssl_verify', true);
			$aResult['calendarMySQLSSLCiphers'] = (string)$oConfig->Get('calendar', 'mysql_ssl_ciphers', '');
			$aResult['calendarSQLiteGlobal'] = !!$oConfig->Get('calendar', 'sqlite_global', false);
			$aResult['calendarMaxRangeDays'] = (int)$oConfig->Get('calendar', 'max_range_days', 400);
			$aResult['calendarMaxOccurrences'] = (int)$oConfig->Get('calendar', 'max_occurrences', 1000);

			$aResult['logsEnable'] = (bool)$oConfig->Get('logs', 'enable', false);
			$aResult['logsPath'] = (string)$oConfig->Get('logs', 'path', '');
			$aResult['logsFilename'] = (string)$oConfig->Get('logs', 'filename', '');
			$aResult['logsLevel'] = (int)$oConfig->Get('logs', 'level', 4);
			$aResult['logsTimeZone'] = (string)$oConfig->Get('logs', 'time_zone', 'UTC');
			$aResult['logsHidePasswords'] = !!$oConfig->Get('logs', 'hide_passwords', true);
			$aResult['logsAuthLogging'] = !!$oConfig->Get('logs', 'auth_logging', false);
			$aResult['logsAuthLoggingFilename'] = (string)$oConfig->Get('logs', 'auth_logging_filename', '');
			$aResult['logsAuthLoggingFormat'] = (string)$oConfig->Get('logs', 'auth_logging_format', '');
			$aResult['logsSyslogIdent'] = (string)$oConfig->Get('logs', 'syslog_ident', 'tachyon');
			$aResult['debugEnable'] = (bool)$oConfig->Get('debug', 'enable', false);
			$aResult['debugJavascript'] = !!$oConfig->Get('debug', 'javascript', false);
			$aResult['debugCss'] = !!$oConfig->Get('debug', 'css', false);

			$aResult['faviconUrl'] = $oConfig->Get('webmail', 'favicon_url', '');
			$aResult['faviconFile'] = $oConfig->Get('webmail', 'favicon_file', '');
			$aResult['faviconMode'] = $oConfig->Get('webmail', 'favicon_mode', 'default');
			$aResult['loginFooter'] = $oConfig->Get('webmail', 'login_footer', '');

			$aResult['weakPassword'] = \is_file(APP_PRIVATE_DATA.'admin_password.txt');

			$aResult['Admin']['language'] = $oActions->ValidateLanguage($oConfig->Get('admin_panel', 'language', 'en'), '', true);
			$aResult['Admin']['languages'] = \Tachyon\Util\L10n::getLanguages(true);
			$aResult['Admin']['clientLanguage'] = $oActions->ValidateLanguage($oActions->detectClientLanguage(true), '', true, true);

			$gnupg = \Tachyon\Util\PGP\GnuPG::getInstance('');
			$gnupgVersion = $gnupg ? ($gnupg->getEngineInfo()['version'] ?? '') : '';
			if (!$gnupgVersion && \extension_loaded('gnupg')) {
				$gnupgVersion = \phpversion('gnupg') ?: 'available';
			}
			$aResult['gnupg'] = $gnupgVersion;
		} else {
			$passfile = APP_PRIVATE_DATA.'admin_password.txt';
			$sPassword = $oConfig->Get('security', 'admin_password', '');
			if (!$sPassword) {
				$sPassword = \substr(\base64_encode(\random_bytes(16)), 0, 12);
				Utils::saveFile($passfile, $sPassword . "\n");
//				\chmod($passfile, 0600);
				$oConfig->SetPassword(new \Tachyon\Util\SensitiveString($sPassword));
				$oConfig->Save();
			}
		}
	}
}
