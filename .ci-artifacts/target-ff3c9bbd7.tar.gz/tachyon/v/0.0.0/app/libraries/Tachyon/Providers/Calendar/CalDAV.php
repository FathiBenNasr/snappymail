<?php

namespace Tachyon\Providers\Calendar;

use Tachyon\Util\DAV\Client as DAVClient;

/**
 * DAV discovery and sync helpers for calendars, mirroring the CardDAV trait used
 * by the address book. The differences are the namespace, the .ics extension, the
 * text/calendar content type, and that an account holds several calendars rather
 * than a single collection.
 */
trait CalDAV
{
	private $aDAVConfig = ['Mode' => 0];

	public function setDAVClientConfig(?array $aConfig)
	{
		if (isset($aConfig['User'], $aConfig['Password'], $aConfig['Url']) && !empty($aConfig['Mode'])) {
			$this->aDAVConfig = $aConfig;
		} else {
			$this->aDAVConfig = ['Mode' => 0];
		}
	}

	protected function isDAVEnabled() : bool
	{
		return !empty($this->aDAVConfig['Mode']);
	}

	/**
	 * Mode 1 is read and write, mode 2 is read only. Anything the user mounts read
	 * only must never receive a PUT or DELETE.
	 */
	protected function isDAVReadWrite() : bool
	{
		return 1 == $this->aDAVConfig['Mode'];
	}

	/**
	 * Fetches a batch of events in one calendar-multiget REPORT.
	 *
	 * Returns filename => iCalendar for everything the server answered with. An
	 * href it declines to return data for is simply absent, and the caller falls
	 * back to a plain GET for those, so a server without multiget still syncs,
	 * just as slowly as before.
	 *
	 * This is what takes an initial sync from one request per event to one per
	 * hundred. A calendar of 5,600 events was 5,600 GETs, which no gateway
	 * timeout survives.
	 */
	protected function davMultiGet(DAVClient $oClient, string $sPath, array $aFileNames) : array
	{
		if (!$aFileNames) {
			return array();
		}

		$sBody = '<?xml version="1.0" encoding="utf-8"?>'
			. '<c:calendar-multiget xmlns:d="DAV:" xmlns:c="urn:ietf:params:xml:ns:caldav">'
			. '<d:prop><d:getetag/><c:calendar-data/></d:prop>';
		foreach ($aFileNames as $sFileName) {
			// Same concatenation the GET path uses, so an href that works there works here
			$sBody .= '<d:href>' . \htmlspecialchars($sPath . $sFileName, ENT_XML1) . '</d:href>';
		}
		$sBody .= '</c:calendar-multiget>';

		$aResult = array();
		try {
			foreach ($oClient->report($sPath, $sBody) as $sHref => $aProps) {
				$sData = $aProps['{urn:ietf:params:xml:ns:caldav}calendar-data'] ?? '';
				if (!\is_string($sData) || !\strlen($sData)) {
					continue;
				}
				$aMatch = array();
				if (\preg_match('/\/([^\/?]+)$/', \rtrim(\trim($sHref), '/'), $aMatch) && !empty($aMatch[1])) {
					$aResult[\urldecode(\urldecode($aMatch[1]))] = $sData;
				}
			}
		} catch (\Throwable $oException) {
			// A server that will not do multiget is not a failure, only slower
			$this->logWrite(
				'calendar-multiget failed, falling back to GET: ' . $oException->getMessage(),
				\LOG_NOTICE, 'Calendar'
			);
		}

		return $aResult;
	}

	/**
	 * Lists the .ics resources of one calendar collection with their etags, which
	 * is what makes a full calendar-query REPORT unnecessary: an etag per resource
	 * is enough to know what changed.
	 */
	protected function prepareDavSyncData(DAVClient $oClient, string $sPath)
	{
		$mResult = false;
		$aResponse = null;
		try
		{
			$aResponse = $oClient->propFind($sPath, array(
				'{DAV:}getlastmodified',
				'{DAV:}resourcetype',
				'{DAV:}getetag'
			), 1);
		}
		catch (\Throwable $oException)
		{
			$this->logException($oException);
		}

		if (\is_array($aResponse)) {
			$mResult = array();
			foreach ($aResponse as $sKey => $aItem) {
				$sKey = \rtrim(\trim($sKey), '\\/');
				if (!empty($sKey) && \is_array($aItem) && isset($aItem['{DAV:}getetag'])) {
					$aMatch = array();
					if (\preg_match('/\/([^\/?]+)$/', $sKey, $aMatch) && !empty($aMatch[1])
					 && !static::hasDAVCollection($aItem))
					{
						$sIcsFileName = \urldecode(\urldecode($aMatch[1]));

						/**
						 * Keyed on the filename, not on the filename with .ics
						 * stripped. A server does not name a resource after the
						 * UID it holds: Nextcloud mints one UUID for the file and
						 * another for the VEVENT. Keying on the stem meant the
						 * local side, which is keyed on the UID, matched almost
						 * nothing, so every event looked deleted and new at once
						 * and was purged and refetched on every run.
						 */
						$mResult[$sIcsFileName] = array(
							'deleted' => false,
							// Only a fallback, for a VEVENT that carries no UID
							'uid' => \preg_replace('/\.ics$/i', '', $sIcsFileName),
							'ics' => $sIcsFileName,
							'etag' => \trim(\trim($aItem['{DAV:}getetag']), '"\''),
							'changed' => 0
						);

						if (isset($aItem['{DAV:}getlastmodified'])) {
							$mResult[$sIcsFileName]['changed'] = \MailSo\Base\DateTimeHelper::ParseRFC2822DateString(
								$aItem['{DAV:}getlastmodified']);
						} else {
							$mResult[$sIcsFileName]['changed'] = \MailSo\Base\DateTimeHelper::TryToParseSpecEtagFormat(
								$mResult[$sIcsFileName]['etag']);
						}
					}
				}
			}
		}

		return $mResult;
	}

	protected function davClientRequest(DAVClient $oClient, string $sCmd, string $sUrl, $mData = null) : ?\Tachyon\Util\HTTP\Response
	{
		\MailSo\Base\Utils::ResetTimeLimit();

		$sLogLine = $sCmd.' '.$sUrl.('PUT' === $sCmd && null !== $mData ? ' ('.\strlen($mData).')' : '');
		$this->logWrite($sLogLine, \LOG_INFO, 'DAV');

		try
		{
			if ('PUT' === $sCmd && null !== $mData) {
				return $oClient->request($sCmd, $sUrl, $mData, array(
					'Content-Type' => 'text/calendar; charset=utf-8'
				));
			}
			return $oClient->request($sCmd, $sUrl);
		}
		catch (\Throwable $oException)
		{
			$this->logWrite($sLogLine.' failed: '.$oException->getMessage(), \LOG_WARNING, 'DAV');
		}

		return null;
	}

	private function detectionPropFind(DAVClient $oClient, string $sPath) : ?array
	{
		try
		{
			return $oClient->propFind($sPath, array(
				'{DAV:}current-user-principal',
				'{DAV:}resourcetype',
				'{DAV:}displayname',
				'{urn:ietf:params:xml:ns:caldav}calendar-home-set'
			), 1);
		}
		catch (\Throwable $oException)
		{
			$this->logException($oException);
		}

		return null;
	}

	/**
	 * Walks .well-known/caldav to the principal, then to calendar-home-set, and
	 * returns every calendar collection found there.
	 *
	 * @return array path => ['name' => ..., 'color' => ..., 'timezone' => ..., 'readOnly' => bool]
	 */
	protected function getCalendarPaths(DAVClient $oClient, string $sPath, string $sUser,
		#[\SensitiveParameter]
		string $sPassword,
		string $sProxy = '') : array
	{
		$sCalendarHomeSet = '';

		$aResponse = $this->detectionPropFind($oClient, '/.well-known/caldav')
			?: $this->detectionPropFind($oClient, $sPath);

		$sCurrentUserPrincipal = '';
		$aHomeSets = array();
		if (\is_array($aResponse)) {
			// Depth 1, so this is keyed by href and every collection under the
			// queried path is in here, not only the one that belongs to the user
			foreach ($aResponse as $sHref => $aItem) {
				if (!empty($aItem['{urn:ietf:params:xml:ns:caldav}calendar-home-set']['{DAV:}href'])) {
					$aHomeSets[$sHref] = $aItem['{urn:ietf:params:xml:ns:caldav}calendar-home-set']['{DAV:}href'];
				}
				if (empty($sCurrentUserPrincipal) && !empty($aItem['{DAV:}current-user-principal']['{DAV:}href'])) {
					$sCurrentUserPrincipal = $aItem['{DAV:}current-user-principal']['{DAV:}href'];
				}
			}
		}

		// The home set belonging to this user, not whichever came first. Radicale
		// redirects /.well-known/caldav to the server root, and that listing
		// advertises a calendar-home-set of "/", so taking the first match sent
		// discovery to the root and away from the path the user configured.
		if (\strlen($sCurrentUserPrincipal)) {
			foreach ($aHomeSets as $sHref => $sHome) {
				if (\rtrim($sHref, '/') === \rtrim($sCurrentUserPrincipal, '/')) {
					$sCalendarHomeSet = $sHome;
					break;
				}
			}
		}
		if (empty($sCalendarHomeSet) && $aHomeSets) {
			$sCalendarHomeSet = \reset($aHomeSets);
		}

		// The home set is often only advertised on the principal, so follow it
		if (empty($sCalendarHomeSet) && !empty($sCurrentUserPrincipal)) {
			$aResponse = $this->detectionPropFind($oClient, $sCurrentUserPrincipal);
			if (\is_array($aResponse)) {
				foreach ($aResponse as $aItem) {
					if (!empty($aItem['{urn:ietf:params:xml:ns:caldav}calendar-home-set']['{DAV:}href'])) {
						$sCalendarHomeSet = $aItem['{urn:ietf:params:xml:ns:caldav}calendar-home-set']['{DAV:}href'];
						break;
					}
				}
			}
		}

		if (empty($sCalendarHomeSet)) {
			// Some servers point straight at a collection, so try the given path itself
			$sCalendarHomeSet = $sPath;
		}

		$oHomeClient = $oClient;
		if (\preg_match('/^http[s]?:\/\//i', $sCalendarHomeSet)) {
			$oHomeClient = $this->getDavClientFromUrl($sCalendarHomeSet, $sUser, $sPassword, $sProxy);
			$sCalendarHomeSet = $oHomeClient->urlPath;
		}

		$aCalendars = $this->listCalendarCollections($oHomeClient, $sCalendarHomeSet);

		// A home set holding no calendars is no better than none at all, and the
		// configured path is the one place we know the user expects them. Only
		// worth a second look when discovery actually walked somewhere else.
		if (!$aCalendars && \rtrim($sCalendarHomeSet, '/') !== \rtrim($sPath, '/')) {
			$aCalendars = $this->listCalendarCollections($oClient, $sPath);
		}

		return $aCalendars;
	}

	protected function listCalendarCollections(DAVClient $oClient, string $sHomeSet) : array
	{
		$aCalendars = array();

		try
		{
			$aResponse = $oClient->propFind($sHomeSet, array(
				'{DAV:}resourcetype',
				'{DAV:}displayname',
				'{DAV:}current-user-privilege-set',
				'{http://apple.com/ns/ical/}calendar-color',
				'{urn:ietf:params:xml:ns:caldav}calendar-timezone',
				'{urn:ietf:params:xml:ns:caldav}supported-calendar-component-set'
			), 1);
		}
		catch (\Throwable $oException)
		{
			$this->logException($oException);
			return $aCalendars;
		}

		if (\is_array($aResponse)) {
			foreach ($aResponse as $sKey => $aItem) {
				if (empty($sKey) || !\is_array($aItem) || !static::isDAVCalendar($aItem)) {
					continue;
				}

				$sName = isset($aItem['{DAV:}displayname']) && \is_string($aItem['{DAV:}displayname'])
					? \trim($aItem['{DAV:}displayname'])
					: '';

				$aCalendars[\rtrim(\trim($sKey), '\\/') . '/'] = array(
					'name' => \strlen($sName) ? $sName : \basename(\rtrim($sKey, '\\/')),
					'color' => static::davCalendarColor($aItem),
					'timezone' => static::davCalendarTimezone($aItem),
					'readOnly' => !static::davCanWrite($aItem)
				);
			}
		}

		return $aCalendars;
	}

	private static function isDAVCalendar($aItem) : bool
	{
		return !empty($aItem['{DAV:}resourcetype'])
			&& \is_array($aItem['{DAV:}resourcetype'])
			&& \in_array('{urn:ietf:params:xml:ns:caldav}calendar', $aItem['{DAV:}resourcetype']);
	}

	private static function hasDAVCollection($aItem) : bool
	{
		return !empty($aItem['{DAV:}resourcetype'])
			&& \is_array($aItem['{DAV:}resourcetype'])
			&& \in_array('{DAV:}collection', $aItem['{DAV:}resourcetype']);
	}

	private static function davCalendarColor($aItem) : string
	{
		$mColor = $aItem['{http://apple.com/ns/ical/}calendar-color'] ?? '';
		if (\is_string($mColor) && \preg_match('/^#[0-9a-f]{3,8}$/i', \trim($mColor), $aMatch)) {
			// Apple appends an alpha pair that CSS before level 4 does not accept
			return \substr($aMatch[0], 0, 7);
		}
		return '';
	}

	private static function davCalendarTimezone($aItem) : string
	{
		$mTimezone = $aItem['{urn:ietf:params:xml:ns:caldav}calendar-timezone'] ?? '';
		if (\is_string($mTimezone) && \strlen($mTimezone)) {
			try {
				$oVCalendar = \Sabre\VObject\Reader::read($mTimezone, \Sabre\VObject\Reader::OPTION_FORGIVING);
				if (isset($oVCalendar->VTIMEZONE)) {
					return (string) $oVCalendar->VTIMEZONE->TZID;
				}
			} catch (\Throwable $oException) {
				// A calendar without a usable default timezone is not an error
			}
		}
		return '';
	}

	/**
	 * Absent privileges are treated as writable, since plenty of servers omit the
	 * property. The configured Mode is what actually protects a read only mount.
	 */
	/**
	 * Only rights that actually allow adding or changing an event count. Matching
	 * "write" loosely also accepts write-properties, which merely permits renaming
	 * or recolouring a calendar. Nextcloud grants exactly that on the generated
	 * birthday calendar, so a loose test offers the user an editable calendar the
	 * server then refuses every event on.
	 */
	private static function davCanWrite($aItem) : bool
	{
		$mPrivileges = $aItem['{DAV:}current-user-privilege-set'] ?? null;
		if (!\is_array($mPrivileges) || !\count($mPrivileges)) {
			// Nothing advertised, so assume writable and let the server refuse
			return true;
		}
		foreach ($mPrivileges as $mItem) {
			if (\is_string($mItem) && \in_array($mItem, array(
				'{DAV:}all',
				'{DAV:}write',
				'{DAV:}write-content',
				'{DAV:}bind'
			))) {
				return true;
			}
		}
		return false;
	}

	private function getDavClientFromUrl(string $sUrl, string $sUser,
		#[\SensitiveParameter]
		string $sPassword,
		string $sProxy = ''
	) : DAVClient
	{
		if (!\preg_match('/^http[s]?:\/\//i', $sUrl)) {
			$sUrl = 'https://'.$sUrl;
		}

		$aUrl = \parse_url($sUrl);
		if (!\is_array($aUrl)) {
			$aUrl = array();
		}

		$aUrl['scheme'] = $aUrl['scheme'] ?? 'http';
		$aUrl['host'] = $aUrl['host'] ?? 'localhost';
		$aUrl['port'] = $aUrl['port'] ?? 0;
		$aUrl['path'] = isset($aUrl['path']) ? \rtrim($aUrl['path'], '\\/').'/' : '/';

		$aSettings = array(
			'baseUri' => $aUrl['scheme'].'://'.$aUrl['host'].($aUrl['port'] ? ':'.$aUrl['port'] : ''),
			'userName' => $sUser,
			'password' => $sPassword
		);

		$this->logMask($sPassword);

		if (!empty($sProxy)) {
			$aSettings['proxy'] = $sProxy;
		}

		$oClient = new DAVClient($aSettings);
		$oClient->setVerifyPeer(false);
		$oClient->urlPath = $aUrl['path'];

		$this->logWrite('DavClient: User: '.$aSettings['userName'].', Url: '.$sUrl, \LOG_INFO, 'DAV');

		return $oClient;
	}

	public function getDavClient() : ?DAVClient
	{
		if (!$this->isDAVEnabled()) {
			return null;
		}
		return $this->getDavClientFromUrl(
			$this->aDAVConfig['Url'],
			$this->aDAVConfig['User'],
			$this->aDAVConfig['Password']
		);
	}
}
